import java.util.Random;

public class Professeurs {

    // Attribut de classe
    public static int nbProfesseurs = 0;

    // Attributs d'instance
    private String nom;
    private int age;
    private char sexe;
    private String matiere;
    private double salaire;

    // Constructeur avec paramètres
    public Professeurs(String nom, int age, char sexe, String matiere, double salaire) {
        this.nom = nom;
        this.age = age;
        this.sexe = sexe;
        this.matiere = matiere;
        this.salaire = salaire;
        // Incrémentation de l'attribut de classea
        nbProfesseurs++;
    }

    // Constructeur aléatoire
    public Professeurs() {
        String[] noms = {"Dupont", "Martin", "Lefebvre", "Meyer", "Bouchard"};
        Random rand = new Random();
        this.nom = noms[rand.nextInt(noms.length)];
        this.age = rand.nextInt(41) + 25;
        this.sexe = rand.nextBoolean() ? 'M' : 'F';
        String[] matieres = {"mathématiques", "français", "anglais", "histoire", "sciences"};
        this.matiere = matieres[rand.nextInt(matieres.length)];
        this.salaire = rand.nextInt(2000) + 3000;
        // Incrémentation de l'attribut de classe
        nbProfesseurs++;
    }

    // Méthodes get/set pour les attributs d'instance
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getSexe() {
        return sexe;
    }

    public void setSexe(char sexe) {
        this.sexe = sexe;
    }

    public String getMatiere() {
        return matiere;
    }

    public void setMatiere(String matiere) {
        this.matiere = matiere;
    }

    public double getSalaire() {
        return salaire;
    }

    public void setSalaire(double salaire) {
        this.salaire = salaire;
    }

    // Méthode pour afficher les informations du professeur
    public void afficherInfos() {
        System.out.println("Nom : " + nom);
        System.out.println("Age : " + age);
        System.out.println("Sexe : " + sexe);
        System.out.println("Matière enseignée : " + matiere);
        System.out.println("Salaire : " + salaire + " €");
    }

    // Méthode pour augmenter le salaire du professeur de 10%
    public void augmenterSalaire() {
        this.salaire *= 1.1;
        System.out.println("Le salaire de " + nom + " a été augmenté de 10%.");
    }

    // Méthode pour vérifier si le professeur enseigne une matière spécifique
    public boolean enseigneMatiere(String matiere) {
        return this.matiere.equals(matiere);
    }


}


