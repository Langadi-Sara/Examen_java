import java.util.Random;

public class Vehicules {


    // Attribut de classe
    private static int nombreVehiculesCrees = 0;

    // Attributs d'instance
    private String modele;
    private String marque;
    private int anneeFabrication;
    private double prix;
    private boolean estLoue;

    // Constructeur avec plusieurs paramètres
    public Vehicules(String modele, String marque, int anneeFabrication, double prix, boolean estLoue) {
        this.modele = modele;
        this.marque = marque;
        this.anneeFabrication = anneeFabrication;
        this.prix = prix;
        this.estLoue = estLoue;
        nombreVehiculesCrees++;
    }

    // Constructeur qui initialise certaines informations de manière aléatoire
    public Vehicules(String modele, String marque) {
        this.modele = modele;
        this.marque = marque;
        this.anneeFabrication = new Random().nextInt(21) + 2000; // Année de fabrication aléatoire entre 2000 et 2020
        this.prix = new Random().nextDouble() * 50000; // Prix aléatoire entre 0 et 50000
        this.estLoue = false;
        nombreVehiculesCrees++;
    }

    // Méthodes get/set
    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public int getAnneeFabrication() {
        return anneeFabrication;
    }

    public void setAnneeFabrication(int anneeFabrication) {
        this.anneeFabrication = anneeFabrication;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public boolean isEstLoue() {
        return estLoue;
    }

    public void setEstLoue(boolean estLoue) {
        this.estLoue = estLoue;
    }

    // Méthode pour louer le véhicule
    public void louer() {
        if (estLoue) {
            System.out.println("Le véhicule est déjà loué.");
        } else {
            estLoue = true;
            System.out.println("Le véhicule a été loué.");
        }
    }

    // Méthode pour rendre le véhicule
    public void rendre() {
        if (!estLoue) {
            System.out.println("Le véhicule n'est pas loué.");
        } else {
            estLoue = false;
            System.out.println("Le véhicule a été rendu.");
        }
    }

    // Méthode pour afficher les informations du véhicule
    public void afficherInformations() {
        System.out.println("Modèle : " + modele);
        System.out.println("Marque : " + marque);
        System.out.println("Année de fabrication : " + anneeFabrication);
        System.out.println("Prix : " + prix);
        if (estLoue) {
            System.out.println("Le véhicule est actuellement loué.");
        } else {
            System.out.println("Le véhicule est disponible.");

        }
    }
}
