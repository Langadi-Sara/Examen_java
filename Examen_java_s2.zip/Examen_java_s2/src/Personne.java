import java.util.Random;

public class Personne {

    private static int nombreTotalPersonnes = 0; // attribut de classe

    private int id; // attribut d'instance
    private String nom; // attribut d'instance
    private int age; // attribut d'instance
    private double taille; // attribut d'instance
    private boolean estMarie; // attribut d'instance

    public Personne(String nom, int age, double taille, boolean estMarie) {
        this.id = ++nombreTotalPersonnes;
        this.nom = nom;
        this.age = age;
        this.taille = taille;
        this.estMarie = estMarie;
    }

    public Personne(String nom, int age) {
        this(nom, age, 0, false); // appel du constructeur avec 4 paramètres
        Random random = new Random();
        this.taille = 1.5 + random.nextDouble() * 0.5; // taille aléatoire entre 1,5 et 2 mètres
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 0 && age <= 120) {
            this.age = age;
        } else {
            System.out.println("Âge invalide.");
        }
    }

    public double getTaille() {
        return taille;
    }

    public boolean estMarie() {
        return estMarie;
    }

    public void marier() {
        if (!estMarie) {
            estMarie = true;
            System.out.println("Félicitations, vous êtes maintenant marié(e) !");
        } else {
            System.out.println("Vous êtes déjà marié(e) !");
        }
    }

    public void divorcer() {
        if (estMarie) {
            estMarie = false;
            System.out.println("Vous êtes maintenant divorcé(e).");
        } else {
            System.out.println("Vous n'êtes pas marié(e) !");
        }
    }

    public void feterAnniversaire() {
        age++;
        System.out.println("Bon anniversaire, vous avez maintenant " + age + " ans !");
    }

    public static void afficherNombreTotalPersonnes() {
        System.out.println("Le nombre total de personnes est : " + nombreTotalPersonnes);
    }

    public static void main(String[] args) {
        Personne p1 = new Personne("Dupont", 30, 1.8, true);
        Personne p2 = new Personne("Martin", 25);
        Personne p3 = new Personne("Durand", 40, 1.7, false);
        Personne p4 = new Personne("Lefebvre", 20);
        Personne p5 = new Personne("Rousseau", 50, 1.6, true);

        System.out.println(p1.getNom() + " a " + p1.getAge() + " ans et mesure " + p1.getTaille() + " mètres.");
        System.out.println(p2.getNom() + " a " + p2.getAge() + " ans et mesure " + p2.getTaille() + " mètres.");
        System.out.println(p3.getNom() + " a " + p3.getAge() + " ans et mesure " + p3.getTaille() + " mètres.");
        System.out.println(p4.getNom() + " a " + p4.getAge() + " ans et mesure " + p4.getTaille() + " mètres.");
        System.out.println(p5.getNom() + " a " + p5.getAge() + " ans et mesure " + p5.getTaille() + " mètres.");
    }
}




