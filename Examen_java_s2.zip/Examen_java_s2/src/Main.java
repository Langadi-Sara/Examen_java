public class Main {
    public static void main(String[] args) {


        Vehicules vehicule1 = new Vehicules("Clio", "Renault", 2015, 10000.0, false);
        vehicule1.afficherInformations();

        Vehicules vehicule2 = new Vehicules("208", "Peugeot");
        vehicule2.afficherInformations();


        Professeurs prof = new Professeurs();
        prof.afficherInfos();
        prof.augmenterSalaire();

        // Accéder à l'attribut de classe nbProfesseurs
        System.out.println("Nombre de professeurs : " + Professeurs.nbProfesseurs);
    }


}
